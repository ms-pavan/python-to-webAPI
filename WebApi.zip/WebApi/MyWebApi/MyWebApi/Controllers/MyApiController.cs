﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MyWebApi.Models;

using DAL;
using System.Web.Script.Serialization;
using System.Collections;
using System.Data;

namespace MyWebApi.Controllers
{
    public class MyApiController : ApiController
    {
        private STRMDMOMEntities2 db = new STRMDMOMEntities2(); 
         [HttpGet]
        public IQueryable<tblPython> Data()
        {
            return db.tblPythons;
        }

         [HttpGet]
        //public IList<tblPython> GetDataPy()
        //{
        //IList<tblPython> configDetails = new List<tblPython>();
        //    using (var context = new STRMDMOMEntities2())
        //    {
        //        IList<tblPython> res = context.getpythondata().ToList();
        //        foreach (tblPython d in res)
        //        {
        //            tblPython config = new tblPython();

        //            config.ID = d.ID;
        //            config.Name = d.Name;
        //            config.SSO = d.SSO;
        //            configDetails.Add(config);
        //        }
        //    }
        //    return configDetails.ToList();
        //}

        //[ActionName("GetString")]
        public string GetString()
        {
            return "Success";
        }

        [HttpGet]
         public DataTable GetDT()
         {
             DataTable table = new DataTable();
             table.Columns.Add("Dosage", typeof(int));
             table.Columns.Add("Drug", typeof(string));
             table.Columns.Add("Patient", typeof(string));
             table.Columns.Add("Date", typeof(DateTime));

             // Here we add five DataRows.
             table.Rows.Add(25, "Indocin", "David", DateTime.Now);
             table.Rows.Add(50, "Enebrel", "Sam", DateTime.Now);
             table.Rows.Add(10, "Hydralazine", "Christoff", DateTime.Now);
             table.Rows.Add(21, "Combivent", "Janet", DateTime.Now);
             table.Rows.Add(100, "Dilantin", "Melanie", DateTime.Now);
             return table;

         }

        [HttpGet]
        //[ActionName("GetAllcarDetails")]
        public IEnumerable<Cars> GetAllcarDetails()
        {
            //Cars ST = new Cars();
            //Cars ST1 = new Cars();
            //List<Cars> li = new List<Cars>();

            //ST.CarName = "Maruti Waganor";
            //ST.CarPrice = "4 Lakh";
            //ST.CarModel = "VXI";
            //ST.CarColor = "Brown";

            //ST1.CarName = "Maruti Swift";
            //ST1.CarPrice = "5 Lakh";
            //ST1.CarModel = "VXI";
            //ST1.CarColor = "RED";

            //li.Add(ST);
            //li.Add(ST1);

            IList<Cars> li = new List<Cars>();
            DataAccessLayer da = new DataAccessLayer();
            li=da.GetData();
            return li;
        }

        public IEnumerable<Cars> Get(int id)
        {
            string len = "";
            for (int i = 1; i < 1000000; i++)
            {
                len += i.ToString();
            }
            Cars ST = new Cars();
            List<Cars> li = new List<Cars>();
            if (id == 1)
            {
                ST.CarName = "Maruti Waganor";
                ST.CarPrice = "4 Lakh";
                ST.CarModel = "VXI";
                ST.CarColor = "Brown";
                li.Add(ST);
            }
            else
            {
                ST.CarName = "Maruti Swift";
                ST.CarPrice = "5 Lakh";
                ST.CarModel = "VXI";
                ST.CarColor = "RED";
                li.Add(ST);
            }
            return li;
        }

        [HttpPost]
        public void PostCar([FromBody] Cars cs)
        {
            DataAccessLayer da = new DataAccessLayer();
            da.Insert(cs);
        }

        [HttpPut]
        public void Putcar(int id, [FromBody]Cars cs)
        {
            DataAccessLayer da = new DataAccessLayer();
            da.Update(cs.Id,cs.CarPrice);
        }

        [HttpDelete]
        public void Deletecar(int id)
        {
            DataAccessLayer da = new DataAccessLayer();
            da.Delete(id);

        }

        [HttpGet]
        public IList<IDictionary> GetCalulationStatus()
        {
            DataAccessLayer da = new DataAccessLayer();
            return da.GetCalulationStatus("D11N2");
        }

       
    }
}
