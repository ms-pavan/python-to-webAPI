﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Collections;


namespace DAL
{
    public class DataAccessLayer 
    {
        string conSTRMD = ConfigurationManager.ConnectionStrings["STRMDConnectionString"].ToString();

        
        public IList<Cars> GetData()
        {
            IList<Cars> list = new List<Cars>();
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conSTRMD;
                connection.Open();
                SqlCommand cmd = new SqlCommand("GetRestdata", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                SqlDataReader sDr = cmd.ExecuteReader();
                if (sDr != null)
                {
                    while (sDr.Read())
                    {
                        Cars model = new Cars();

                        model.CarName = Convert.ToString(sDr["CarName"]);
                        model.CarModel = Convert.ToString(sDr["CarModel"]);
                        model.CarPrice = Convert.ToString(sDr["CarPrice"]);
                        model.CarColor = Convert.ToString(sDr["CarColor"]);
                        list.Add(model);
                    }
                }

            }

            return list;

        }
        
         
        public void Insert(Cars cs)
        {
            
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conSTRMD;
                connection.Open();
                SqlCommand cmd = new SqlCommand("InsertRestdata", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                cmd.Parameters.AddWithValue("@Id", cs.Id);
                cmd.Parameters.AddWithValue("@CarName", cs.CarName);
                cmd.Parameters.AddWithValue("@CarModel", cs.CarModel);
                cmd.Parameters.AddWithValue("@CarPrice", cs.CarPrice);
                cmd.Parameters.AddWithValue("@CarColor" ,cs.CarColor);


                int rec = cmd.ExecuteNonQuery();
                
            }
        }
        public void Delete(int Id)
        {
            
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conSTRMD;
                connection.Open();
                SqlCommand cmd = new SqlCommand("deleterestdata", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                cmd.Parameters.AddWithValue("@Id",Id);

                int rec = cmd.ExecuteNonQuery();
                
            }
        }
        public void Update(int Id,string Price)
        {
            
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conSTRMD;
                connection.Open();
                SqlCommand cmd = new SqlCommand("updaterestdata", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                cmd.Parameters.AddWithValue("@Id",Id);
                cmd.Parameters.AddWithValue("@Price", Price);

                int rec = cmd.ExecuteNonQuery();
                
            }
        }



        public IList<IDictionary> GetCalulationStatus(string qType)
        {
            SqlConnection strmdConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["STRMDConnectionString"].ConnectionString);
            SqlCommand sqlCommand = new SqlCommand("GetCalculationStatus", strmdConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@QType", qType);
            strmdConnection.Open();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataSet dataSet = new DataSet();
            sqlDataAdapter.Fill(dataSet);
            DataTable calculationStatusDataTable = dataSet.Tables[0];
            strmdConnection.Close();
            return ConvertToListDictionary(calculationStatusDataTable);

        }

        private List<IDictionary> ConvertToListDictionary(DataTable dtObject)
        {
            var columns = dtObject.Columns.Cast<DataColumn>();

            var dictionaryList = dtObject.AsEnumerable()
                .Select(dataRow => columns
                    .Select(column =>
                        new { Column = column.ColumnName, Value = dataRow[column] })
                             .ToDictionary(data => data.Column, data => data.Value)).ToList().ToArray();

            return dictionaryList.ToList<IDictionary>();

        }
    }
}
