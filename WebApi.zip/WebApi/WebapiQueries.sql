CREATE TABLE tblRestService (
        Id INT ,
        CarName VARCHAR(100),
		CarModel VARCHAR(100),
		CarPrice VARCHAR(100),
		CarColor VARCHAR(100))

		insert into tblRestService values('Swift','VXI','8L','White')
		insert into tblRestService values('Duster','VXI','12L','Black')

		select * from tblRestService

		delete from tblRestService
		drop table tblRestService
			create procedure GetRestdata
		as
		begin
		select * from tblRestService

		end


		DROP PROCEDURE insertrestdata
		create procedure insertrestdata(
		@Id INT ,
		@CarName VARCHAR(100),
		@CarModel VARCHAR(100),
		@CarPrice VARCHAR(100),
		@CarColor VARCHAR(100)
		)
		as
		begin
		insert into tblRestService(Id,CarName,CarModel, CarPrice, CarColor) values(@Id,@CarName, @CarModel, @CarPrice, @CarColor)

		end


		

		
	    create procedure updaterestdata(
		@Id INT,
		@Price varchar(100)
		)
		as
		begin
		update tblRestService set carprice= @Price where id=@Id

		end

	    create procedure deleterestdata(
		@Id INT
		)
		as
		begin
		delete from  tblRestService where id=@Id

		end







		sp_helptext getdailydata