--TABLE TO SAVE THE DATA
CREATE TABLE tblRestService (
Id INT ,
CarName VARCHAR(100),
CarModel VARCHAR(100),
CarPrice VARCHAR(100),
CarColor VARCHAR(100)
)
GO

--PROCEDURE TO GET THE DATA
CREATE PROCEDURE GetRestdata
AS
BEGIN
SELECT * FROM tblRestService
END
GO
--PROCEDURE TO INSERT THE DATA
CREATE PROCEDURE INSERTrestdata(
@Id INT ,
@CarName VARCHAR(100),
@CarModel VARCHAR(100),
@CarPrice VARCHAR(100),
@CarColor VARCHAR(100)
)
AS
BEGIN
INSERT INTO tblRestService(Id,CarName,CarModel, CarPrice, CarColor) VALUES(@Id,@CarName, @CarModel, @CarPrice, @CarColor)
END
GO
--PROCEDURE TO UPDATE THE DATA
CREATE PROCEDURE updaterestdata(
@Id INT,
@Price varchar(100)
)
AS
BEGIN
update tblRestService set carprice= @Price where id=@Id
END
 GO  
--PROCEDURE TO DELETE THE DATA   
CREATE PROCEDURE DELETErestdata(
@Id INT
)
AS
BEGIN
DELETE FROM  tblRestService where id=@Id
END
GO