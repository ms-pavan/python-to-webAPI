---Run the WebapiQueriesCRUD sql script in SQLServer database to create 
database objects

---Open WebAPI with VisualStudio 2010

---Deploy WebApi in IIS or run locally

---Use the ActionNames in python code to perform CRUD operations