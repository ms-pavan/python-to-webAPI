﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Collections;


namespace DAL
{
    public class DataAccessLayer 
    {
        string conSTRMD = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

        
        public IList<Cars> GetData()
        {
            IList<Cars> list = new List<Cars>();
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conSTRMD;
                connection.Open();
                SqlCommand cmd = new SqlCommand("GetRestdata", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                SqlDataReader sDr = cmd.ExecuteReader();
                if (sDr != null)
                {
                    while (sDr.Read())
                    {
                        Cars model = new Cars();

                        model.CarName = Convert.ToString(sDr["CarName"]);
                        model.CarModel = Convert.ToString(sDr["CarModel"]);
                        model.CarPrice = Convert.ToString(sDr["CarPrice"]);
                        model.CarColor = Convert.ToString(sDr["CarColor"]);
                        list.Add(model);
                    }
                }

            }

            return list;

        }
        
         
        public void Insert(Cars cs)
        {
            
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conSTRMD;
                connection.Open();
                SqlCommand cmd = new SqlCommand("InsertRestdata", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                cmd.Parameters.AddWithValue("@Id", cs.Id);
                cmd.Parameters.AddWithValue("@CarName", cs.CarName);
                cmd.Parameters.AddWithValue("@CarModel", cs.CarModel);
                cmd.Parameters.AddWithValue("@CarPrice", cs.CarPrice);
                cmd.Parameters.AddWithValue("@CarColor" ,cs.CarColor);


                int rec = cmd.ExecuteNonQuery();
                
            }
        }
        public void Delete(int Id)
        {
            
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conSTRMD;
                connection.Open();
                SqlCommand cmd = new SqlCommand("deleterestdata", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                cmd.Parameters.AddWithValue("@Id",Id);

                int rec = cmd.ExecuteNonQuery();
                
            }
        }
        public void Update(int Id,string Price)
        {
            
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conSTRMD;
                connection.Open();
                SqlCommand cmd = new SqlCommand("updaterestdata", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                cmd.Parameters.AddWithValue("@Id",Id);
                cmd.Parameters.AddWithValue("@Price", Price);

                int rec = cmd.ExecuteNonQuery();
                
            }
        }
                
    }
}
