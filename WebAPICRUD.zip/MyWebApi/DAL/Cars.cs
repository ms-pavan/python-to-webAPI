﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class Cars
    {
        public int Id { get; set; }
        public string CarName { get; set; }
        public string CarModel { get; set; }
        public string CarPrice { get; set; }
        public string CarColor { get; set; }
    }
}
