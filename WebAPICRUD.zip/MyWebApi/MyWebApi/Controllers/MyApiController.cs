﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MyWebApi.Models;

using DAL;
using System.Web.Script.Serialization;
using System.Collections;
using System.Data;

namespace MyWebApi.Controllers
{
    public class MyApiController : ApiController
    {       
        [HttpGet]
        //[ActionName("GetAllcarDetails")]
        public IEnumerable<Cars> GetAllcarDetails()
        {          

            IList<Cars> li = new List<Cars>();
            DataAccessLayer da = new DataAccessLayer();
            li=da.GetData();
            return li;
        }
        
        [HttpPost]
        public void PostCar([FromBody] Cars cs)
        {
            DataAccessLayer da = new DataAccessLayer();
            da.Insert(cs);
        }

        [HttpPut]
        public void Putcar(int id, [FromBody]Cars cs)
        {
            DataAccessLayer da = new DataAccessLayer();
            da.Update(cs.Id,cs.CarPrice);
        }

        [HttpDelete]
        public void Deletecar(int id)
        {
            DataAccessLayer da = new DataAccessLayer();
            da.Delete(id);
        }
       
    }
}
